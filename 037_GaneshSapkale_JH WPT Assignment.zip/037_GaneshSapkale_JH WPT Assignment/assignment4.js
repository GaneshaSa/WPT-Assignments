const url=" ";
const dbconn={
    host:'localhost',
    user:'root',
    password:'cdac',
    database:'ganesha',
    port:3306
};

const mysql=require('mysql2');
const con=mysql.createConnection(dbconn);
console.log("Database connecting");

const express = require('express');
const app = express();

app.use(express.static("cp"))


app.get('/pin',(req,res)=>{


    let input= req.query.pincode;
    let output={status:false, city:"",message:"Pincode not found"};

    con.query('select areaname from pincodedata where pincode=?',[input],(err,rows)=>{
        if(err){
            console.log("error has occured let us see");
        }
        else{
            if(rows.length>0)
            {
                output.status=true;
                output.message="Pincode found";
                output.city=rows[0].areaname;
                
            }
        }
        res.send(output);
    });

});


app.get('/getname',(req,res)=>{
    let x=req.query.name;
    res.send(x);
  
})

app.listen(900,function(){
    console.log("server listening at port 900 ...")
});
