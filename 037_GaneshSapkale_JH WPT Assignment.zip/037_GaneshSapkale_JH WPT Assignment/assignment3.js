

const url=" ";
const dbconn={
    host:'localhost',
    user:'root',
    password:'cdac',
    database:'ganesha',
    port:3306
};

const mysql=require('mysql2');
const con=mysql.createConnection(dbconn);
console.log("Database connecting");

 con.query('update resource set status=? where resource_id=?',["true",5],(err,res)=>{
    if(err){
        console.log(err)
    }
    else{
        
        if(res.affectedRows===0)
        {
            console.log('not updated')
        }else if(res.affectedRows>0)
        {
            console.log(res.affectedRows);
            console.log('update successful')
        }
    }
 }); 



 con.query('select * from resource',[],(err,rows)=>{
    if(err){
        console.log(err);
    }
    else
        console.log(rows);
    
}); 