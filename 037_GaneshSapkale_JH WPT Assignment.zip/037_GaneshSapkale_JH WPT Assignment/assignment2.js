
const url=" ";
const dbconn={
    host:'localhost',
    user:'root',
    password:'cdac',
    database:'ganesha',
    port:3306
};

const mysql=require('mysql2');
const con=mysql.createConnection(dbconn);
console.log("Database connecting");

//code to check database connection
con.connect((err)=>{
    if
        (err) throw err;
    
    console.log("Database Connected Successfuly")
});


con.query('select * from dept',[],(err,res)=>{
    if(err){
        console.log("Error in program \n"+err);
    }
    else{
        console.log(res);
    }
});